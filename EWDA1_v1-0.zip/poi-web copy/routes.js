const POI = require("./app/controllers/poi");

module.exports = [
  { method: "GET", path: "/", config: POI.index },
  {
    method: "GET",
    path: "/{param*}",
    handler: {
      directory: {
        path: "./public",
      },
    },
  },
  { method: "GET", path: "/signup", config: POI.signup },
  { method: "GET", path: "/login", config: POI.login },
];
